function addLoadEvent(func) {
  var oldonload = window.onload;

  if (typeof window.onload != 'function') {
    window.onload = func;
  } else {
    window.onload = function() {
      if (oldonload) {
        oldonload();
      }
      func();
    }
  }
}



function add_print_link( id ){

  if( !document.getElementById ||
      !document.getElementById( id ) ) return;

  // add extra functions to page tools list
  var print_page = document.getElementById( id );

  // create print link
  var print_function = document.createElement('p');

  print_function.className = 'print-link';
  print_function.onclick = function(){ print_preview(); return false; };
  var test= document.createTextNode( 'Print the Page' );
 
  print_function.appendChild( test );
  print_page.appendChild(print_function);

}

addLoadEvent( function(){ add_print_link( 'nav' ) } );
function print_preview() {
	

	// Print the page
	window.print();
}



